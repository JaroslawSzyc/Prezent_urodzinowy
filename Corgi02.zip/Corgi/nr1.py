import pygame
import random
#cd Desktop\Studia\Sem5\Corgi


pygame.init()

win = pygame.display.set_mode((400,500))
pygame.display.set_caption("Dla Ani")

# graphics
bg=pygame.image.load(r'.\\obrazki\\bg.jpg')
psy=[pygame.image.load(r'.\\obrazki\\1.jpg'),pygame.image.load(r'.\\obrazki\\2.jpg'),pygame.image.load(r'.\\obrazki\\4.jpg'),pygame.image.load(r'.\\obrazki\\5.jpg'),pygame.image.load(r'.\\obrazki\\6.jpg'),pygame.image.load(r'.\\obrazki\\7.jpg'),
pygame.image.load(r'.\\obrazki\\8.jpg'),pygame.image.load(r'.\\obrazki\\9.jpg'),pygame.image.load(r'.\\obrazki\\10.jpg'),pygame.image.load(r'.\\obrazki\\11.jpg'),pygame.image.load(r'.\\obrazki\\12.jpg'),pygame.image.load(r'.\\obrazki\\13.jpg'),
pygame.image.load(r'.\\obrazki\\15.jpg'),pygame.image.load(r'.\\obrazki\\16.jpg'),pygame.image.load(r'.\\obrazki\\17.jpg'),pygame.image.load(r'.\\obrazki\\18.jpg'),pygame.image.load(r'.\\obrazki\\19.jpg'),pygame.image.load(r'.\\obrazki\\20.jpg'),
pygame.image.load(r'.\\obrazki\\21.jpg'),pygame.image.load(r'.\\obrazki\\22.jpg'),pygame.image.load(r'.\\obrazki\\23.jpg'),pygame.image.load(r'.\\obrazki\\24.jpg')]

teksciory=['Ale krzywa akcja!', 'am am am am!', 'Ja też!', 'Czas na kebsa!', 'CZEKOLADA!!!', 'Choco choco', 'A może frytki do tego?', " I'm lovin' it", 'Life tastes great!', 'Zahirek?', 'Meat is back on menu boys!!', 
'*hungry noises*', '*slurp*', 'Gimmie gimme gimme a food after midnight', 'Chce jeść', 'Kto wybrzydza ten chodzi głodny', 'Hoooman, gimmie food!', 'Nakarm pieseła',"It's not a screen issue", ' Squirwiel' ,
 'Eeeeee Makarena', 'Niesamowita sprawa, dziwne nie?', 'A bez pałacu... Nie ma pałacu', 'Takie tam stożki', 'PC masterrace','Gdyby mi się tak chciało...','No we','Halp meh','Mam spanko',
 'Zmenczonma jestem','Turli turli','AUU AUU','Aaa przemsań przemsań','Jeszcze jak','Ale że tak chłop z chłopem??','Witaj książę!','Wyszkolę cię w jeden księżyc','Petarda!', 'Tak trzymać!', 'Afirmacja życia',
  'Pytasz mnie skąd mam ten...?', 'Everybody pomarańcze','Ludzie potrzebują Cię!','Kochać znaczy powstawać','Time goes by, no time to cry',
  'Perfectly balanced...','Co za miejsce, nie do życia','Co kraj to obyczaj','LUL','PogChamp','Oof','MORTAL KOMBAT!!!',':>','ayyyyy','ARRIBA ARRIBA!!!','Wanna dance with me?','Bruh','Sklejasz akcje???','Ogar zią',
  'Imakuruku eruczene iuczene','Fajna kiecka szefie','Siaaaanko','Kałamba','Happy biwday uwu','BEDZIE TEGO','Ten grobowiec...','Zawsze to jakaś pamiątka','Nie chcesz UTSZEBE?','Pokaż mi swoje towary','Bywaj!','Zaraza',
  'Szybciej Płotka!','Partyjka Gwinta?','A Sasin skradł 70 mln','2.137 w skali Sasina','Ziooooobro','Kończa mi się pomysły','Toss a coin to your Witcher','Skurtem Asterigzmie! Skurtem!','AAAAA OBERWAŁEM',
  'Z kojotem.. no wiesz','Powiedz mi to prosto w profil!','Nami rządzi papież','Dobrze, że jesteś! :>']
# print('-------------------------', len(teksciory))
game_scene=0
a=0
b=0

    


class button():
    '''przyciski'''
    def __init__(self, color, x,y, width,height, text=''):
        self.color = color
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.text = text

    def draw(self,win,outline=None):
        '''rysowanie przycisku, argumentem jest okno i ew. czy przyciski mają mieć obwódkę'''
        # if outline:
        #     pygame.draw.rect(win, outline, (self.x-2,self.y-2,self.width+4,self.height+4),0)
            
        pygame.draw.rect(win, self.color, (self.x,self.y,self.width,self.height),0)
        
        if self.text != '':
            font = pygame.font.SysFont('Arial', 25, True)
            text = font.render(self.text, 1, (0,0,0))
            win.blit(text, (self.x + (self.width/2 - text.get_width()/2), self.y + (self.height/2 - text.get_height()/2)))

    def isOver(self, pos):
        '''funckja określa czy mysz znajduje się na powierzchni przycisku'''
        if pos[0] > self.x and pos[0] < self.x + self.width:
            if pos[1] > self.y and pos[1] < self.y + self.height:
                
                return True
            
        return False


class teksty(object):
    '''obiekty tekstowe'''
    
    def __init__(self,x,y,text,size,color,B=None):
        #podstawowe parametry
        self.x=x
        self.y=y
        self.text=text
        self.size=size
        self.color=color
        self.B=B

    def draw(self,win):
        '''rysowanie tekstu'''
        font=pygame.font.SysFont('TimesNewRoman',self.size,self.B)
        text=font.render(self.text,1,self.color)
        win.blit(text,(self.x,self.y))

    def apdejt(self,tekst,kolor=None):
        '''aktualizowanie istniejącej instancji tekstowej'''
        self.text=tekst
        if kolor!=None:
            self.color=kolor



def redraw():
    '''główna funckja naszej gry, za jej pomoca rysujemy praktycznie wszystkie instancje
    trzymanie instancji w listach jest super rozwiązaniem, gdyż wówczas łatwo możemy na nich operować
    możemy używać pętli lub nawet usuwać instancje'''

    win.blit(bg,(0,0))

    if game_scene==1:
        win.blit(psy[a],(45,80))

        
    for butt in things:
        butt.draw(win)




things=[]


run = True
while run:
    # print(a)
    # print(game_scene)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

    if game_scene==0:
        things.clear()
        Button1=button((255,64,64),150,350,80,50,'Poka')
        Button2=button((255,64,64),1160,400,80,50,'Hide')
        tekst1=teksty(1020,1030,'tekst mema',30,(0,0,0))
        things.extend([Button1, Button2, tekst1])



    if game_scene==1:
        things.clear()
        Button1=button((255,64,64),11360,400,80,50,'Show')
        Button2=button((255,64,64),130,400,110,50,'Wraacaj')
        tekst1=teksty(45,45,teksciory[b],25,(0,0,0))
        things.extend([Button1, Button2, tekst1])





    pos=pygame.mouse.get_pos()
    if event.type == pygame.MOUSEBUTTONDOWN:
            if Button1.isOver(pos) :
                game_scene=1
                a=random.randint(0,21)
                b=random.randint(0,len(teksciory)-1)

            if Button2.isOver(pos):
                game_scene=0
        





    pygame.display.update()
    redraw()
pygame.quit() 